function  [W, h, A, B, ind, objhis] = inmf_W( v, W, h, A, B, rank, beta, alpha);

%% INPUT
% v: new sample to be processed by INMF (column vector)
% W: mixing matrix
% h: initial encoding vector
% A = the matrix V*H' 
% B = the matrix H*H' 
% rank : matrix factorization rank
% beta, alpha = weights that measures the contribution of the new sample

%% OUTPUT
% W: Mixing matrix (v=Wh)
% h: Encoding ecor (v=Wh)
% A = the matrix V*H'+v*h'
% B = the matrix H*H'+h*h'
% ind: the indices of the columns of W that are updates (not allcolumns of W are updated) 
% objhis: reconstruction error history

vdim = size(W,1);
% [T]=sel_otsu(h');
% ind=find(h>=T);

[so si] = sort(h,'descend');
if size(W,2)>4
    ind=si(1:4);
else
    ind=1:size(W,2);
end
% if ( max(size(h))>1 && max(size(ind))<2)
%     h2=sort(h);
%     b=h2(end);
%     ind(1)=find(h==b);
%     b=h2(end-1);
%     ind(2)=find(h==b);
% end

Wv=W'*v;  % dim : rankx1
WW=W'*W;  % dim : rankxrank (symmetric)
vh=v*h';
hh=h*h';
A2=A(:,ind);
B2=B(:,ind);
W2=W(:,ind);

% objhistory = ((sum(sum((v-W*h).^2))))/(vdim);
%     figure(1); clf;
%     drawnow;
% Start iteration
iter = 0;
while 1
  
    if (iter==200)
        break
    end
    
    iter = iter+1;    

%     h = h.*(W'*v)./(W'*W*h + 1e-9); 
%     W = W.*((beta*A+alpha*v*h')./(W*(beta*B+alpha*h*h') + 1e-9));
    h = h.*(Wv)./(WW*h + 1e-9); 
    vh=v*h';
    hh=h*h';
    
    W2 = W2.*((beta*A2+alpha*vh(:,ind))./(W*(beta*B2+alpha*hh(:,ind)) + 1e-9));
    tempWv = W2'*v;
    for i=1:max(size(ind))
        Wv(ind(i))=tempWv(i);
    end
    
    tempWW = W2'*W;
    tempWW_t=tempWW';
    for i=1:max(size(ind))  % Lets assume the 2nd and 4th columns of W are needed to be updated. Then, only the 2nd and 4th rows and columns of 
        % the matrix W'*W need to be changed. Note that W'*W is a symmetric matrix 
        WW(ind(i),:)=tempWW(i,:);
        WW(:,ind(i))=tempWW_t(:,i);
    end
    
    for i=1:max(size(ind))
        W(:,ind(i))=W2(:,i);
    end
    newobj = ((sum(sum((v-W*h).^2)))/(vdim));
    if iter==1
        objhis=newobj;
    else
        objhis=[objhis newobj];
    end
    
%      if (iter>1)
%             plot(objhis(2:end)); 
%         end
%         drawnow;
        
end

A=beta*A+alpha*v*h';
B=beta*B+alpha*h*h';
