% 30 October 2001
% Serhat Selcuk Bucak, bucakser@msu.edu 
%
% - Note that this `simplified code` is written for demontration purposes and to help
% other researchers for implementing comp-INMF. 
% - This code has not been checked throughly and might contain bugs. If you happen to find errors, 
% please send an email to me. 
% - In this code, we assume that the number of instances to be processed is
% small and can be stored in the matrix Vdat. Many personal computers would restrict you to use less than 
% 10K frames due to RAM constraints. If you want to run online experiments in larger datasest you should modify the code
  and load each frame iteratively instead of storing the whole data matrix.

- type help comp_INMF.m to the command window for more info.

- If you use the code, please cite:
  -- S.S. Bucak, B. Gunsel, "Online Video Scene Clustering by Competitive Incremental NMF," Signal Image and Video Processing (accepted for publication). 