% 30 October 2001
% Serhat Selcuk Bucak, bucakser@msu.edu 
%
%[frame_error, H, label, min_max, centr] = comp_INMF(V, Vdat, beta, alpha,thr_rec, thr_h)
%
%INPUT
% - V = Data matrix that contains the initial video frames (each column is a single video frame representation) 
% that will be processed via batch NMF and serve as a initial point for comp-INMF
% - Vdat = Data matrix that contains the video frames (each column is a single video frame representation) 
% that will be processed via comp-INMF 
% - beta, alpha: weighting coefficients (we used alpha=beta=1 in the paper)
% - thr_h: threshold value in terms of distance between encoding vectors and cluster centers
% - thr_rec: threshold value in terms of reconstruction error
%
% OUTPUT
% frame_error: recontruction error (each component corresponds to an individual frame)
% H : matrix that holds individual encoding vectors, h.
% label : the cluster assingment vector (each component corresponds to an individual frame).
% min_max : for each instance (video frame), the distance between it and the closest cluster center 
% centr: the matrix that holds the cluster centers

%
% - Note that this `simplified code` is written for demontration purposes and to help
% other researchers for implementing comp-INMF. 
% - This code has not been checked throughly and might contain bugs. If you happen to find errors, 
% please send an email to me. 
% - In this code, we assume that the number of instances to be processed is
% small and can be stored in the matrix Vdat. Many personal computers would restrict you to use less than 
% 10K frames due to RAM constraints. If you want to run online experiments in larger datasest you should modify the code
% and load each frame iteratively instead of storing the whole data matrix.

function [frame_error, H, label, min_max, centr] = comp_INMF(V, Vdat, beta, alpha, thr_rec, thr_h)

fprintf('....Initial Training Phase.....\n');

min_num=50;  % min number of samples that is needed to form in a cluster (this is used for more advanced experiments)
[W, H] = nmf( V, 1, 0, 100); % rank=1, number of iterations=100, 0 means no graphs
vdim=size(W,1);
samples=size(V,2);
A=V*H';
B=H*H';
recons=W*H;
rank=size(H,1);
rec_err = calc_frame_err(V,recons); %hata means error in Turkish
ind=[];
ind2=[];
label=[];
frame_error=[];
centr(:,1)=mean(H,2); % just like Kmeans, we calculate cluster center as the mean of the samples
centr(:,1)=centr(:,1)/sum(centr(:,1));

sample_num(1)=max(min_num);  % number of samples that each cluster contains

minss=0;
row=1;

for i=1:size(Vdat,2)
    
    fprintf('Processing frame no [%d]\n', i);
    v=Vdat(:,i);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [W, h] = nmf_h(v, W, rank, 0, 40); % 40 is the number of max iterations
    h2=h;
    proj_err = calc_frame_err(v,W*h);
    [min_max_dist, s] = comp_distance(centr, h/sum(h)); % distance between each cluster center (components/columns of the matrix centr) and normalized h
    s=s(end);
    min_max(i)=min_max_dist;
    if(min_max_dist>thr_h | proj_err>thr_rec)   %| ((min(h_err)>tr_h | rec_err>tr_rec) | W_karsilastir(W1,W2)<tr_W)
        %%%%%%%%%% add a new cluster %%%%%%%%%%%%5
        rank=rank+1
        h=[h2;1];
        A=dim_inc_2(A);
        W=[W v];
        B=dim_inc(B);
        centr=dim_inc_1(centr);
        [W, h, A, B, ind] = inmf_W(v, W, h, A, B, rank, beta, alpha);
        proj_err = calc_frame_err(v,W*h);
        centr=[centr h/sum(h)];
        sample_num=[sample_num 1];
        label=[label rank];

      
    else %no new clusters
        [W, h, A, B, ind] = inmf_W(v, W, h, A, B, rank, beta, alpha);
        recons=W*h;
        centr(:,s)=((centr(:,s)*sample_num(s))+h/sum(h))/(sample_num(s)+1);          %update the corresponding cluster center
        sample_num(s)=sample_num(s)+1;                                          % update the number of samples in the corresponding cluster   
        label=[label s];  % update the cluster assignment vector          
    end
    frame_error=[frame_error proj_err];

end