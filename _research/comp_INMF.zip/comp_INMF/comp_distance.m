% this codes calculates the infinity norm distance between the sample h and
% each of the cluster centers and assigns h to the center that gives the
% smallest error.
function [min_max_dist, s] = comp_distance(centr, h)
% centr: matrix of cluster centers
% h: a sample



for j=1:size(centr,2)
    for i=1:size(centr,1)
        dist(i,j)=abs(centr(i,j)-h(i)); % check each components for each cluster center (infinity norm)
    end
end

max_dist=max(dist);  % take the max component for each cluster
min_max_dist=min(max_dist);  % choose the smallest one
s=find(max_dist==min_max_dist); % Find the matching cluster