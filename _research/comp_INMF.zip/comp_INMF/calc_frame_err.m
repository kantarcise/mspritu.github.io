function [hata] = calc_frame_err(V,T)
% V : original matrix (each column is a single sample)
% T : recontruction matrix (each column is a single sample)

frame_number=size(V,2);
sizes=size(V,1);
for i=1:frame_number
    hata(i)=(sum((V(:,i)-T(:,i)).^2))/(sizes);
end
%figure(2);
%plot(hata)