- See example.m to see how the code works.
- Please report any problems or errors to Serhat Bucak: bucakser@msu.edu
- If you use the code, please cite:
  S.S. Bucak, B. Gunsel, "Incremental Subspace Learning via Non-negative Matrix Factorization," <i> Pattern Recognition </i>, vol 42(5), pp. 788-797, May 2009. 

