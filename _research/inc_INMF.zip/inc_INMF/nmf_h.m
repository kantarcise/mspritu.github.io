% Hoer's code (P. O. Hoyer. Non-negative Matrix Factorization with sparseness constraints. 
% Journal of Machine Learning Research  5:1457-1469, 2004.) is modified 


function [W, H] = nmf_h( V, W, rdim, showflag, ttt )
% Regular NMF but W is not updated

%% INPUT
% V: data matrix
% rdim : matrix factorization rank
% showflag: if it is 1. than it plots the change of reconstruction error
% for each iteration
% ttt: maximum number of iterations allowed

%% OUTPUT
% W: Mixing matrix (V=WH)
% H: Encoding matrix (V=WH)


% Check that we have non-negative data
if min(V(:))<0, error('Negative values in data!'); end
 
% Dimensions
vdim = size(V,1);
samples = size(V,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% initialization %%%

fname2=['initials/Initials' num2str(rdim) 'x' num2str(samples) '.txt'];
fid=fopen(fname2,'r');
if (fid==-1)
    ssbinitial(rdim,samples);
else
    fclose(fid);
end
fidW2 = fopen(fname2,'r');
H = fscanf(fidW2,'%f', [rdim inf]);

fclose(fidW2);

clear fname2
clear fid;
clear fidW2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (showflag==1)
    objhistory = sqrt((sum(sum((V-W*H).^2))))/(vdim*samples);
    figure(1); clf;
    drawnow;
end


% Start iteration
iter = 0;
while 1,
    
    if (iter==ttt)
        break
    end
    iter = iter+1;    
    % Compute new W and H (Lee and Seung; NIPS*2000)
    H = H.*(W'*V)./(W'*W*H + 1e-9);    
    if(showflag==1)
        newobj = sqrt((sum(sum((V-W*H).^2))))/(vdim*samples);
        objhistory = [objhistory newobj];
        if (iter>1)
            plot(objhistory(2:end)); 
        end
        drawnow;
    end   
end